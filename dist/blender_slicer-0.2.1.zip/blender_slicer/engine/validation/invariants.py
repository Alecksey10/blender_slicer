
class Invariants:
    pass
